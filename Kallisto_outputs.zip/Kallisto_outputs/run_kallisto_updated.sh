#!/bin/bash

# Path to your Kallisto index
index="short_orfs.index"

# Typical fragment length and standard deviation
fragment_length=75
std_dev=10

# Loop through each FASTQ file in the directory
for file in *.fastq.gz; do
    # Extract the base name of the file (remove the .fastq.gz extension)
    base=$(basename $file .fastq.gz)
    
    # Create an output directory for each file
    output_dir="${base}_kallisto_output"
    mkdir -p $output_dir

    # Run Kallisto
    kallisto quant -i $index -o $output_dir --single -l $fragment_length -s $std_dev $file
    
    echo "Finished processing $file"
done

