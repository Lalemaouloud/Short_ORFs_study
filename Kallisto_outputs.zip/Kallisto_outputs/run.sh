#!/bin/bash
#SBATCH -t 19:00:00
#SBATCH --mem=300G
#SBATCH -o Run37_download_out.txt
#SBATCH -e Run37_download_err.txt
#SBATCH --mail-user=lale@ebi.ac.uk
#SBATCH --cpus-per-task=45
#SBATCH --mail-type=BEGIN

#SBATCH --mail-type=END

source activate ggc_env
bash run_kallisto_updated.sh
